var Config = Config || {};
Config.gearInfo = ['2x','6x','2x','4x','5x','4x','8x','4x','3x','5x','3x','10x','6x','2x','2x','3x','10x','8x'];

module.exports = Config;